'use client';

import { useState, useEffect } from 'react';
import { PageHeader, KpiStrip, type KpiItem } from '@/components/enterprise';
import { Headphones, TicketCheck, Clock, CheckCircle, AlertTriangle, Calendar, BarChart3, Users } from 'lucide-react';
import { usePJ } from '@/lib/pj-context';
import Link from 'next/link';

export default function ServiceDeskDashboard() {
  const { activeCompanyId } = usePJ();
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  const kpis: KpiItem[] = [
    { label: 'Tickets Abertos', value: '0', icon: <TicketCheck className="w-5 h-5" /> },
    { label: 'Em Atendimento', value: '0', icon: <Clock className="w-5 h-5" /> },
    { label: 'Resolvidos (Mês)', value: '0', icon: <CheckCircle className="w-5 h-5" /> },
    { label: 'SLA Excedido', value: '0', icon: <AlertTriangle className="w-5 h-5" /> },
  ];

  if (!mounted) return null;

  const quickLinks = [
    { href: '/pj/servicedesk/tickets', label: 'Tickets', icon: TicketCheck, color: 'text-blue-500' },
    { href: '/pj/servicedesk/agenda', label: 'Agenda', icon: Calendar, color: 'text-green-500' },
    { href: '/pj/servicedesk/agentes', label: 'Agentes', icon: Headphones, color: 'text-purple-500' },
    { href: '/pj/servicedesk/grupos', label: 'Grupos', icon: Users, color: 'text-amber-500' },
    { href: '/pj/servicedesk/relatorios', label: 'Relatórios', icon: BarChart3, color: 'text-cyan-500' },
    { href: '/pj/servicedesk/portal', label: 'Portal', icon: Headphones, color: 'text-red-500' },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title="ServiceDesk" subtitle="Gestão de chamados e atendimento" />
      <KpiStrip items={kpis} />
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {quickLinks.map(link => (
          <Link key={link.href} href={link.href}
            className="bg-card border border-border/60 rounded-xl p-5 flex flex-col items-center gap-3 hover:shadow-lg hover:border-primary/30 transition-all group">
            <link.icon className={`w-8 h-8 ${link.color} group-hover:scale-110 transition-transform`} />
            <span className="text-sm font-medium text-foreground">{link.label}</span>
          </Link>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card border border-border/60 rounded-xl p-6">
          <h3 className="text-lg font-semibold mb-4">Tickets Recentes</h3>
          <p className="text-muted-foreground text-sm">Nenhum ticket registrado. Comece criando um novo chamado.</p>
        </div>
        <div className="bg-card border border-border/60 rounded-xl p-6">
          <h3 className="text-lg font-semibold mb-4">Performance da Equipe</h3>
          <p className="text-muted-foreground text-sm">Dados de performance serão exibidos após o primeiro atendimento.</p>
        </div>
      </div>
    </div>
  );
}
