'use client';
import { apiFetch } from '@/lib/fetch';
import { TicketCheck } from 'lucide-react';
import { useEffect, useState } from 'react';
import { CheckCircle, Clock, Headphones } from 'lucide-react';
import { PageHeader } from '@/components/enterprise';


export default function Page() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch('/api/pj/servicedesk/tickets').then(r => r.json())
      .then(d => setTickets(Array.isArray(d) ? d : []))
      .catch(() => {}).finally(() => setLoading(false));
  }, []);

  const total = tickets.length;
  const open = tickets.filter((t: any) => t.status === 'open' || t.status === 'in_progress').length;
  const resolved = tickets.filter((t: any) => t.status === 'resolved' || t.status === 'closed').length;
  const critical = tickets.filter((t: any) => t.priority === 'critical' || t.priority === 'high').length;

  return (
    <div className="space-y-6">
      <PageHeader title="Relatórios ServiceDesk" subtitle="Métricas e análises de atendimento" />
      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" /></div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'Total Tickets', value: total, icon: TicketCheck, color: 'text-blue-600' },
              { label: 'Abertos', value: open, icon: Clock, color: 'text-amber-600' },
              { label: 'Resolvidos', value: resolved, icon: CheckCircle, color: 'text-green-600' },
              { label: 'Críticos', value: critical, icon: Headphones, color: 'text-red-600' },
            ].map(k => (
              <div key={k.label} className="bg-card border border-border/60 rounded-xl p-4 text-center">
                <k.icon className={`w-6 h-6 mx-auto mb-2 ${k.color}`} />
                <p className={`text-2xl font-bold ${k.color}`}>{k.value}</p>
                <p className="text-xs text-muted-foreground">{k.label}</p>
              </div>
            ))}
          </div>
          <div className="bg-card border border-border/60 rounded-xl p-4">
            <h3 className="font-semibold mb-3">Tickets por Prioridade</h3>
            {['critical', 'high', 'medium', 'low'].map(p => {
              const count = tickets.filter((t: any) => t.priority === p).length;
              const labels: Record<string,string> = { 'critical': '🔴 Crítica', 'high': '🟠 Alta', 'medium': '🟡 Média', 'low': '🟢 Baixa' };
              const pct = total > 0 ? (count / total * 100).toFixed(0) : '0';
              return (
                <div key={p} className="flex items-center gap-3 py-2 border-b border-border/30 last:border-0">
                  <span className="text-sm w-24">{labels[p]}</span>
                  <div className="flex-1 bg-muted rounded-full h-2"><div className="bg-blue-500 h-2 rounded-full" style={{ width: `${pct}%` }} /></div>
                  <span className="font-bold text-sm w-12 text-right">{count}</span>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
