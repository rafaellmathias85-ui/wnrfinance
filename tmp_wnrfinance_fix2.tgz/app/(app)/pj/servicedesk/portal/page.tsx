'use client';
import { apiFetch } from '@/lib/fetch';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Globe, Plus, Search } from 'lucide-react';
import { PageHeader } from '@/components/enterprise';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';


export default function Page() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    apiFetch('/api/pj/servicedesk/tickets').then(r => r.json())
      .then(d => setTickets(Array.isArray(d) ? d : []))
      .catch(() => {}).finally(() => setLoading(false));
  }, []);

  const filtered = tickets.filter((t: any) =>
    t.subject?.toLowerCase().includes(search.toLowerCase()) ||
    t.requesterName?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <PageHeader title="Portal do Cliente" subtitle="Visualização de chamados pelo cliente" />
      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Buscar chamado..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Link href="/pj/servicedesk/tickets">
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
            <Plus className="w-4 h-4 mr-1" /> Novo Chamado
          </Button>
        </Link>
      </div>
      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" /></div>
      ) : (
        <div className="space-y-3">
          {filtered.length === 0 ? (
            <div className="bg-card border border-border/60 rounded-xl p-8 text-center">
              <Globe className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-30" />
              <p className="text-muted-foreground">Nenhum chamado encontrado</p>
            </div>
          ) : filtered.map((t: any) => {
            const statusMap: Record<string,string> = { 'open': '🟡 Aberto', 'in_progress': '🔵 Em Andamento', 'resolved': '🟢 Resolvido', 'closed': '⚫ Fechado' };
            return (
              <div key={t.id} className="bg-card border border-border/60 rounded-xl p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-semibold">{t.subject}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{t.requesterName || 'Sem solicitante'} • {t.createdAt ? new Date(t.createdAt).toLocaleDateString('pt-BR') : ''}</p>
                  </div>
                  <span className="text-xs font-medium">{statusMap[t.status] || t.status}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
