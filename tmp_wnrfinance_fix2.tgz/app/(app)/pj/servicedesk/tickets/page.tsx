'use client';

import { CrudPage } from '@/components/enterprise';

export default function Page() {
  return (
    <CrudPage
      title="Tickets"
      subtitle="Gerenciar chamados de suporte"
      apiUrl="/api/pj/servicedesk/tickets"
      entityName="ticket"
      newLabel="Novo Ticket"
      columns={[
    { key: 'number', label: 'Nº' },
    { key: 'subject', label: 'Assunto' },
    { key: 'requester', label: 'Solicitante' },
    { key: 'agentName', label: 'Agente' },
    { key: 'priority', label: 'Prioridade', render: (v: any) => { const m: Record<string,string> = { 'baixa': 'Baixa', 'media': 'Média', 'alta': 'Alta', 'critica': 'Crítica' }; return m[v] || v || '—'; } },
    { key: 'status', label: 'Status', render: (v: any) => { const m: Record<string,string> = { 'aberto': 'Aberto', 'em_atendimento': 'Em Atendimento', 'pendente': 'Pendente', 'resolvido': 'Resolvido', 'fechado': 'Fechado' }; return m[v] || v || '—'; } }
  ]}
      fields={[
    { key: 'subject', label: 'Assunto', required: true },
    { key: 'description', label: 'Descrição', type: 'textarea' },
    { key: 'requester', label: 'Solicitante' },
    { key: 'requesterEmail', label: 'E-mail do Solicitante', type: 'email' },
    { key: 'agentName', label: 'Agente' },
    { key: 'priority', label: 'Prioridade', type: 'select', defaultValue: 'media', options: [{ value: 'baixa', label: 'Baixa' }, { value: 'media', label: 'Média' }, { value: 'alta', label: 'Alta' }, { value: 'critica', label: 'Crítica' }] },
    { key: 'status', label: 'Status', type: 'select', defaultValue: 'aberto', options: [{ value: 'aberto', label: 'Aberto' }, { value: 'em_atendimento', label: 'Em Atendimento' }, { value: 'pendente', label: 'Pendente' }, { value: 'resolvido', label: 'Resolvido' }, { value: 'fechado', label: 'Fechado' }] },
    { key: 'category', label: 'Categoria' }
  ]}
    />
  );
}
