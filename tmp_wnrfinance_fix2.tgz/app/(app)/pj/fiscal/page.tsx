'use client';
import { apiFetch } from '@/lib/fetch';
import { Calculator } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { toast } from 'sonner';
import { Calendar, CheckCircle, Clock, FileText, RefreshCw } from 'lucide-react';


interface TaxRecord { id: string; type: string; period: string; year: number; month?: number; baseValue: number; taxValue: number; rate?: number; status: string; dueDate?: string; paidAt?: string; paidAmount?: number; notes?: string; metadata?: any; }
interface DASCalc { regime: string; anexo?: string; bruto12Months: number; receitaMes: number; aliquotaNominal: number; aliquotaEfetiva: number; dasAmount: number; details: string; breakdown?: Record<string, number>; }

const fmtCurrency = (v: number) => v?.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const fmtDate = (v: string) => v ? new Date(v).toLocaleDateString('pt-BR') : '-';
const now = new Date();

const STATUS_BADGE: Record<string, string> = {
  aberto: 'text-yellow-400 bg-yellow-900/30',
  pago: 'text-green-400 bg-green-900/30',
  vencido: 'text-red-400 bg-red-900/30',
  dispensado: 'text-slate-400 bg-slate-800',
};

type Tab = 'das' | 'icms';

export default function FiscalPJPage() {
  const searchParams = useSearchParams();
  const [activeTab, setActiveTab] = useState<Tab>(searchParams.get('type') === 'ICMS' ? 'icms' : 'das');

  // DAS state
  const [records, setRecords] = useState<TaxRecord[]>([]);
  const [calc, setCalc] = useState<DASCalc | null>(null);
  const [dueDate, setDueDate] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [calcLoading, setCalcLoading] = useState(false);
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [showMarkPaid, setShowMarkPaid] = useState<TaxRecord | null>(null);

  // ICMS/ISS state
  const [icmsRecords, setIcmsRecords] = useState<TaxRecord[]>([]);
  const [icmsLoading, setIcmsLoading] = useState(false);
  const [icmsYear, setIcmsYear] = useState(now.getFullYear());
  const [showNewIcms, setShowNewIcms] = useState(false);

  const loadDAS = useCallback(async () => {
    setLoading(true);
    const r = await apiFetch(`/api/pj/fiscal?year=${year}&action=calculate&month=${month}`);
    const d = await r.json();
    setRecords(d.records || []);
    setCalc(d.calculation || null);
    setDueDate(d.dueDate ? new Date(d.dueDate).toLocaleDateString('pt-BR') : '');
    setLoading(false);
  }, [year, month]);

  const loadICMS = useCallback(async () => {
    setIcmsLoading(true);
    const r = await apiFetch(`/api/pj/fiscal?year=${icmsYear}&type=ICMS`);
    const d = await r.json();
    setIcmsRecords(d.records || []);
    setIcmsLoading(false);
  }, [icmsYear]);

  useEffect(() => { if (activeTab === 'das') loadDAS(); }, [activeTab, loadDAS]);
  useEffect(() => { if (activeTab === 'icms') loadICMS(); }, [activeTab, loadICMS]);

  const generateDAS = async () => {
    setCalcLoading(true);
    const r = await apiFetch('/api/pj/fiscal', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ generateDAS: true, year, month }),
    });
    if (r.ok) { toast.success('DAS gerado e salvo!'); loadDAS(); }
    else { const d = await r.json(); toast.error(d.error || 'Erro ao gerar DAS'); }
    setCalcLoading(false);
  };

  const markPaid = async (record: TaxRecord, paidAmount: string, paidAt: string) => {
    const r = await apiFetch(`/api/pj/fiscal/${record.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'pago', paidAmount: parseFloat(paidAmount), paidAt }),
    });
    if (r.ok) {
      toast.success('Marcado como pago');
      setShowMarkPaid(null);
      if (activeTab === 'das') loadDAS(); else loadICMS();
    } else toast.error('Erro ao atualizar');
  };

  const months = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Módulo Fiscal PJ</h1>
          <p className="text-slate-400 text-sm mt-0.5">Impostos, DAS, ICMS, ISS e outros tributos</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-800/60 border border-slate-700 rounded-xl p-1 w-fit">
        {([
          { id: 'das' as Tab, label: 'DAS / Simples Nacional', icon: Calculator },
          { id: 'icms' as Tab, label: 'ICMS / ISS', icon: FileText },
        ] as const).map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-slate-700 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'das' && (
        <>
          {/* Period selector */}
          <div className="flex items-center gap-3">
            <select value={month} onChange={e => setMonth(parseInt(e.target.value))}
              className="bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2">
              {months.map((m, i) => <option key={i+1} value={i+1}>{m}</option>)}
            </select>
            <select value={year} onChange={e => setYear(parseInt(e.target.value))}
              className="bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2">
              {[now.getFullYear() - 1, now.getFullYear(), now.getFullYear() + 1].map(y => <option key={y}>{y}</option>)}
            </select>
          </div>

          {/* DAS Calculator */}
          {calc && (
            <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-green-400" />
                  Cálculo DAS — {months[month - 1]}/{year}
                </h2>
                <div className="flex items-center gap-2 text-slate-400 text-sm">
                  <Calendar className="w-4 h-4" />
                  Vencimento: <span className="text-white font-medium">{dueDate}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="bg-slate-900/60 rounded-lg p-3">
                  <p className="text-slate-400 text-xs">Regime</p>
                  <p className="text-white font-semibold mt-1">{calc.regime} {calc.anexo ? `— Anexo ${calc.anexo}` : ''}</p>
                </div>
                <div className="bg-slate-900/60 rounded-lg p-3">
                  <p className="text-slate-400 text-xs">Receita do Mês</p>
                  <p className="text-white font-semibold mt-1">{fmtCurrency(calc.receitaMes)}</p>
                </div>
                <div className="bg-slate-900/60 rounded-lg p-3">
                  <p className="text-slate-400 text-xs">Alíquota Efetiva</p>
                  <p className="text-white font-semibold mt-1">{calc.aliquotaEfetiva.toFixed(2).replace('.', ',')}%</p>
                </div>
                <div className="bg-green-900/40 border border-green-700/40 rounded-lg p-3">
                  <p className="text-green-300 text-xs">DAS a Pagar</p>
                  <p className="text-green-400 font-bold text-xl mt-1">{fmtCurrency(calc.dasAmount)}</p>
                </div>
              </div>

              {calc.breakdown && (
                <div className="flex flex-wrap gap-3 text-sm text-slate-400 mb-4">
                  {Object.entries(calc.breakdown).map(([k, v]) => (
                    <span key={k}>{k}: <span className="text-white">{fmtCurrency(v as number)}</span></span>
                  ))}
                </div>
              )}

              <p className="text-slate-500 text-xs mb-4">{calc.details}</p>

              <button onClick={generateDAS} disabled={calcLoading}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-lg text-sm font-medium">
                <RefreshCw className={`w-4 h-4 ${calcLoading ? 'animate-spin' : ''}`} />
                {calcLoading ? 'Gerando...' : 'Gerar DAS e Salvar'}
              </button>
            </div>
          )}

          {/* DAS Records table */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-700">
              <h2 className="text-white font-semibold">Registros Fiscais — {year}</h2>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-slate-900/60">
                <tr>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Tipo</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Período</th>
                  <th className="text-right px-4 py-3 text-slate-400 font-medium">Base</th>
                  <th className="text-right px-4 py-3 text-slate-400 font-medium">Imposto</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Vencimento</th>
                  <th className="text-center px-4 py-3 text-slate-400 font-medium">Status</th>
                  <th className="text-center px-4 py-3 text-slate-400 font-medium">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {loading ? (
                  <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">Carregando...</td></tr>
                ) : records.length === 0 ? (
                  <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">Nenhum registro. Gere o DAS acima para começar.</td></tr>
                ) : records.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-700/30">
                    <td className="px-4 py-3">
                      <span className="font-medium text-white">{r.type}</span>
                      {r.rate && <span className="text-slate-400 text-xs ml-2">{r.rate.toFixed(2)}%</span>}
                    </td>
                    <td className="px-4 py-3 text-slate-300">{r.period}</td>
                    <td className="px-4 py-3 text-right text-slate-300">{fmtCurrency(r.baseValue)}</td>
                    <td className="px-4 py-3 text-right text-white font-semibold">{fmtCurrency(r.taxValue)}</td>
                    <td className={`px-4 py-3 ${r.status === 'aberto' && r.dueDate && new Date(r.dueDate) < new Date() ? 'text-red-400' : 'text-slate-300'}`}>
                      {fmtDate(r.dueDate || '')}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${STATUS_BADGE[r.status] || STATUS_BADGE.aberto}`}>
                        {r.status === 'pago' ? <CheckCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        {r.status.charAt(0).toUpperCase() + r.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {r.status === 'aberto' && (
                        <button onClick={() => setShowMarkPaid(r)} className="text-green-400 hover:text-green-300 text-xs">Marcar como pago</button>
                      )}
                      {r.status === 'pago' && r.paidAt && <span className="text-slate-500 text-xs">Pago em {fmtDate(r.paidAt)}</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {activeTab === 'icms' && (
        <>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <select value={icmsYear} onChange={e => setIcmsYear(parseInt(e.target.value))}
                className="bg-slate-800 border border-slate-700 text-white text-sm rounded-lg px-3 py-2">
                {[now.getFullYear() - 1, now.getFullYear(), now.getFullYear() + 1].map(y => <option key={y}>{y}</option>)}
              </select>
            </div>
            <button
              onClick={() => setShowNewIcms(true)}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-medium"
            >
              + Lançar Imposto
            </button>
          </div>

          {/* Info box */}
          <div className="bg-blue-900/20 border border-blue-700/40 rounded-xl p-4">
            <p className="text-blue-300 text-sm font-medium mb-1">ICMS / ISS — Impostos estaduais e municipais</p>
            <p className="text-blue-400/80 text-xs">
              ICMS: imposto sobre circulação de mercadorias (alíquota varia por estado, geralmente 7%–18%).
              ISS: imposto sobre serviços (alíquota municipal, geralmente 2%–5%). Registre os valores mensais e marque como pago após o recolhimento.
            </p>
          </div>

          {/* ICMS/ISS Records */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-700">
              <h2 className="text-white font-semibold">ICMS / ISS — {icmsYear}</h2>
            </div>
            <table className="w-full text-sm">
              <thead className="bg-slate-900/60">
                <tr>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Tipo</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Período</th>
                  <th className="text-right px-4 py-3 text-slate-400 font-medium">Base</th>
                  <th className="text-right px-4 py-3 text-slate-400 font-medium">Imposto</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-medium">Vencimento</th>
                  <th className="text-center px-4 py-3 text-slate-400 font-medium">Status</th>
                  <th className="text-center px-4 py-3 text-slate-400 font-medium">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {icmsLoading ? (
                  <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">Carregando...</td></tr>
                ) : icmsRecords.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-12 text-center">
                      <FileText className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                      <p className="text-slate-500">Nenhum lançamento de ICMS/ISS para {icmsYear}.</p>
                      <p className="text-slate-600 text-xs mt-1">Use o botão "Lançar Imposto" para registrar.</p>
                    </td>
                  </tr>
                ) : icmsRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-700/30">
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${r.type === 'ICMS' ? 'bg-orange-900/30 text-orange-300' : 'bg-blue-900/30 text-blue-300'}`}>{r.type}</span>
                      {r.rate && <span className="text-slate-400 text-xs ml-2">{r.rate.toFixed(2)}%</span>}
                    </td>
                    <td className="px-4 py-3 text-slate-300">{r.period}</td>
                    <td className="px-4 py-3 text-right text-slate-300">{fmtCurrency(r.baseValue)}</td>
                    <td className="px-4 py-3 text-right text-white font-semibold">{fmtCurrency(r.taxValue)}</td>
                    <td className={`px-4 py-3 ${r.status === 'aberto' && r.dueDate && new Date(r.dueDate) < new Date() ? 'text-red-400' : 'text-slate-300'}`}>
                      {fmtDate(r.dueDate || '')}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${STATUS_BADGE[r.status] || STATUS_BADGE.aberto}`}>
                        {r.status === 'pago' ? <CheckCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        {r.status.charAt(0).toUpperCase() + r.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {r.status === 'aberto' && (
                        <button onClick={() => setShowMarkPaid(r)} className="text-green-400 hover:text-green-300 text-xs">Marcar como pago</button>
                      )}
                      {r.status === 'pago' && r.paidAt && <span className="text-slate-500 text-xs">Pago em {fmtDate(r.paidAt)}</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {showNewIcms && <NewIcmsDialog onClose={() => setShowNewIcms(false)} onSaved={loadICMS} />}
        </>
      )}

      {showMarkPaid && <MarkPaidModal record={showMarkPaid} onClose={() => setShowMarkPaid(null)} onSave={markPaid} />}
    </div>
  );
}

function NewIcmsDialog({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    type: 'ISS', period: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`,
    baseValue: '', rate: '', taxValue: '', dueDate: '', notes: '',
  });
  const [saving, setSaving] = useState(false);

  const calcTax = (base: string, rate: string) => {
    const b = parseFloat(base), r = parseFloat(rate);
    if (!isNaN(b) && !isNaN(r)) setForm(prev => ({ ...prev, taxValue: (b * r / 100).toFixed(2) }));
  };

  const save = async () => {
    if (!form.baseValue || !form.taxValue) { toast.error('Preencha os valores'); return; }
    setSaving(true);
    const [y, m] = form.period.split('-');
    const r = await apiFetch('/api/pj/fiscal', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: form.type,
        period: form.period,
        year: parseInt(y),
        month: parseInt(m),
        baseValue: parseFloat(form.baseValue),
        rate: parseFloat(form.rate) || null,
        taxValue: parseFloat(form.taxValue),
        dueDate: form.dueDate || null,
        notes: form.notes || null,
      }),
    });
    if (r.ok) { toast.success('Imposto registrado'); onSaved(); onClose(); }
    else { const d = await r.json(); toast.error(d.error || 'Erro ao salvar'); }
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 w-full max-w-md space-y-4">
        <h3 className="text-lg font-bold text-white">Lançar ICMS / ISS</h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-slate-400 mb-1">Tipo</label>
            <select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))}
              className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm">
              <option value="ISS">ISS</option>
              <option value="ICMS">ICMS</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">Período (AAAA-MM)</label>
            <input type="month" value={form.period} onChange={e => setForm(p => ({ ...p, period: e.target.value }))}
              className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">Base de Cálculo (R$)</label>
            <input type="number" step="0.01" value={form.baseValue}
              onChange={e => { setForm(p => ({ ...p, baseValue: e.target.value })); calcTax(e.target.value, form.rate); }}
              className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">Alíquota (%)</label>
            <input type="number" step="0.01" value={form.rate}
              onChange={e => { setForm(p => ({ ...p, rate: e.target.value })); calcTax(form.baseValue, e.target.value); }}
              className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">Valor do Imposto (R$)</label>
            <input type="number" step="0.01" value={form.taxValue} onChange={e => setForm(p => ({ ...p, taxValue: e.target.value }))}
              className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">Vencimento</label>
            <input type="date" value={form.dueDate} onChange={e => setForm(p => ({ ...p, dueDate: e.target.value }))}
              className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm" />
          </div>
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Observações</label>
          <input type="text" value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))}
            className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm" />
        </div>
        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg text-sm">Cancelar</button>
          <button onClick={save} disabled={saving} className="flex-1 bg-blue-600 hover:bg-blue-500 text-white py-2 rounded-lg text-sm font-medium">
            {saving ? 'Salvando...' : 'Salvar'}
          </button>
        </div>
      </div>
    </div>
  );
}

function MarkPaidModal({ record, onClose, onSave }: { record: TaxRecord; onClose: () => void; onSave: (r: TaxRecord, amt: string, dt: string) => void }) {
  const [amount, setAmount] = useState(String(record.taxValue));
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 border border-slate-700 rounded-xl p-6 w-full max-w-sm space-y-4">
        <h3 className="text-lg font-bold text-white">Registrar Pagamento</h3>
        <p className="text-slate-400 text-sm">{record.type} — {record.period}</p>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Valor pago (R$)</label>
          <input type="number" value={amount} onChange={e => setAmount(e.target.value)} step="0.01"
            className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">Data do pagamento</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)}
            className="w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-3 py-2 text-sm" />
        </div>
        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg text-sm">Cancelar</button>
          <button onClick={() => onSave(record, amount, date)} className="flex-1 bg-green-600 hover:bg-green-500 text-white py-2 rounded-lg text-sm font-medium">Confirmar</button>
        </div>
      </div>
    </div>
  );
}

