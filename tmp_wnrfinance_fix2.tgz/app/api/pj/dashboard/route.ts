export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
  const companyId = session.user.activeCompanyId;
  if (!companyId) return NextResponse.json({ error: 'Nenhuma empresa ativa' }, { status: 400 });

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);

  const [payables, receivables, paidPayables, receivedReceivables, overduePayables, overdueReceivables] = await Promise.all([
    prisma.accountsPayable.aggregate({
      where: { companyId, dueDate: { gte: startOfMonth, lte: endOfMonth } },
      _sum: { amount: true }, _count: true,
    }),
    prisma.accountsReceivable.aggregate({
      where: { companyId, dueDate: { gte: startOfMonth, lte: endOfMonth } },
      _sum: { amount: true }, _count: true,
    }),
    prisma.accountsPayable.aggregate({
      where: { companyId, status: 'pago', paidAt: { gte: startOfMonth, lte: endOfMonth } },
      _sum: { amount: true },
    }),
    prisma.accountsReceivable.aggregate({
      where: { companyId, status: 'recebido', receivedAt: { gte: startOfMonth, lte: endOfMonth } },
      _sum: { amount: true },
    }),
    prisma.accountsPayable.aggregate({
      where: { companyId, status: 'pendente', dueDate: { lt: now } },
      _sum: { amount: true }, _count: true,
    }),
    prisma.accountsReceivable.aggregate({
      where: { companyId, status: 'pendente', dueDate: { lt: now } },
      _sum: { amount: true }, _count: true,
    }),
  ]);

  const [recentPayables, recentReceivables] = await Promise.all([
    prisma.accountsPayable.findMany({
      where: { companyId }, orderBy: { createdAt: 'desc' }, take: 5,
      include: { category: true },
    }),
    prisma.accountsReceivable.findMany({
      where: { companyId }, orderBy: { createdAt: 'desc' }, take: 5,
      include: { category: true },
    }),
  ]);

  // Investment summary
  const [investmentSummary, investmentsByType, reconciliationStats] = await Promise.all([
    prisma.pJInvestment.aggregate({
      where: { companyId, status: 'ativo' },
      _sum: { amountInvested: true, currentValue: true },
      _count: true,
    }),
    prisma.pJInvestment.groupBy({
      by: ['investmentType'],
      where: { companyId, status: 'ativo' },
      _sum: { currentValue: true },
      _count: true,
    }),
    prisma.pJReconciliation.groupBy({
      by: ['status'],
      where: { companyId },
      _count: true,
    }),
  ]);

  // Category breakdown for payables
  const payablesByCategory = await prisma.accountsPayable.groupBy({
    by: ['categoryId'],
    where: { companyId, dueDate: { gte: startOfMonth, lte: endOfMonth } },
    _sum: { amount: true },
    _count: true,
  });

  // Fetch category names for the breakdown
  const categoryIds = payablesByCategory.filter((c: any) => c.categoryId).map((c: any) => c.categoryId!);
  const categoryNames = categoryIds.length > 0 ? await prisma.businessCategory.findMany({
    where: { id: { in: categoryIds } },
    select: { id: true, name: true },
  }) : [];
  const catMap = Object.fromEntries(categoryNames.map((c: any) => [c.id, c.name]));

  const paid = paidPayables._sum?.amount || 0;
  const received = receivedReceivables._sum?.amount || 0;

  return NextResponse.json({
    month: {
      payables: { total: payables._sum?.amount || 0, count: payables._count },
      receivables: { total: receivables._sum?.amount || 0, count: receivables._count },
      paid,
      received,
      balance: received - paid,
    },
    overdue: {
      payables: { total: overduePayables._sum?.amount || 0, count: overduePayables._count },
      receivables: { total: overdueReceivables._sum?.amount || 0, count: overdueReceivables._count },
    },
    recent: { payables: recentPayables, receivables: recentReceivables },
    investments: {
      totalInvested: investmentSummary._sum?.amountInvested || 0,
      currentValue: investmentSummary._sum?.currentValue || 0,
      count: investmentSummary._count,
      byType: investmentsByType.map(t => ({ type: t.investmentType, value: t._sum?.currentValue || 0, count: t._count })),
    },
    reconciliation: Object.fromEntries(reconciliationStats.map(r => [r.status, r._count])),
    payablesByCategory: payablesByCategory.map(c => ({
      category: c.categoryId ? (catMap[c.categoryId] || 'Sem categoria') : 'Sem categoria',
      total: c._sum?.amount || 0,
      count: c._count,
    })),
  });
}
