export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function PUT(req: NextRequest, { params }: any) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
  const { id } = await params;
  const companyId = session.user.activeCompanyId;
  if (!companyId) return NextResponse.json({ error: 'Nenhuma empresa ativa' }, { status: 400 });

  const existing = await prisma.accountsReceivable.findFirst({ where: { id, companyId } });
  if (!existing) return NextResponse.json({ error: 'Não encontrado' }, { status: 404 });

  const body = await req.json();
  const data: any = {};
  if (body.description !== undefined) data.description = body.description;
  if (body.customerName !== undefined) data.customerName = body.customerName;
  if (body.amount !== undefined) data.amount = parseFloat(body.amount);
  if (body.dueDate !== undefined) data.dueDate = new Date(body.dueDate);
  if (body.receivedAt !== undefined) data.receivedAt = body.receivedAt ? new Date(body.receivedAt) : null;
  if (body.amountReceived !== undefined) data.amountReceived = body.amountReceived ? parseFloat(body.amountReceived) : null;
  if (body.status !== undefined) data.status = body.status;
  if (body.categoryId !== undefined) data.categoryId = body.categoryId || null;
  if (body.costCenterId !== undefined) data.costCenterId = body.costCenterId || null;
  if (body.notes !== undefined) data.notes = body.notes;

  const updated = await prisma.accountsReceivable.update({ where: { id }, data });
  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: any) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
  const { id } = await params;
  const companyId = session.user.activeCompanyId;
  if (!companyId) return NextResponse.json({ error: 'Nenhuma empresa ativa' }, { status: 400 });

  const existing = await prisma.accountsReceivable.findFirst({ where: { id, companyId } });
  if (!existing) return NextResponse.json({ error: 'Não encontrado' }, { status: 404 });

  await prisma.accountsReceivable.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
