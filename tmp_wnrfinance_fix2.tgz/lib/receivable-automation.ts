// Motor de automação: AccountsReceivable → NF-e + Boleto/PIX
// Chamado após criar/atualizar uma conta a receber com autoNfe ou autoBoleto = true

import { prisma } from '@/lib/prisma';
import { emitNFe, type NFePayload } from '@/lib/nfe';
import { createCharge, type ChargePayload } from '@/lib/boleto';

export type AutomationResult = {
  nfe?: { id: string; status: string; errorMessage?: string };
  boleto?: { id: string; status: string; errorMessage?: string };
};

export async function runReceivableAutomation(
  receivableId: string,
  companyId: string,
  opts?: { nfe?: boolean; boleto?: boolean }
): Promise<AutomationResult> {
  const receivable = await prisma.accountsReceivable.findUnique({
    where: { id: receivableId },
  });
  if (!receivable) return {};

  const doNfe = opts?.nfe ?? receivable.autoNfe;
  const doBoleto = opts?.boleto ?? receivable.autoBoleto;

  const result: AutomationResult = {};

  const [nfeRes, boletoRes] = await Promise.allSettled([
    doNfe ? generateNFe(receivable, companyId) : Promise.resolve(null),
    doBoleto ? generateBoleto(receivable, companyId) : Promise.resolve(null),
  ]);

  if (nfeRes.status === 'fulfilled' && nfeRes.value) result.nfe = nfeRes.value;
  if (boletoRes.status === 'fulfilled' && boletoRes.value) result.boleto = boletoRes.value;

  return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// Gerar NF-e
// ─────────────────────────────────────────────────────────────────────────────
async function generateNFe(
  receivable: any,
  companyId: string
): Promise<{ id: string; status: string; errorMessage?: string }> {
  // Idempotência: não gerar se já existe
  const existing = await prisma.nFe.findFirst({
    where: { receivableId: receivable.id, status: { notIn: ['cancelada', 'rejeitada'] } },
    select: { id: true, status: true },
  });
  if (existing) return { id: existing.id, status: existing.status };

  const payload: NFePayload = {
    naturezaOperacao: 'Prestação de Serviço',
    destinatarioNome: receivable.customerName || 'Consumidor Final',
    destinatarioDoc: receivable.customerDoc || '000.000.000-00',
    destinatarioEmail: receivable.customerEmail || undefined,
    items: [
      {
        codigo: '001',
        descricao: receivable.description,
        unidade: 'UN',
        quantidade: 1,
        valorUnitario: receivable.amount,
        valorTotal: receivable.amount,
      },
    ],
    informacoesAdicionais: receivable.notes || undefined,
  };

  // Cria registro como rascunho antes de tentar emitir
  const nfe = await prisma.nFe.create({
    data: {
      companyId,
      receivableId: receivable.id,
      status: 'rascunho',
      customerName: receivable.customerName,
      customerDoc: receivable.customerDoc,
      customerEmail: receivable.customerEmail,
      items: payload.items as any,
      totals: { totalNota: receivable.amount } as any,
      createdBy: receivable.createdBy,
    },
  });

  const emitResult = await emitNFe(companyId, payload);

  const updated = await prisma.nFe.update({
    where: { id: nfe.id },
    data: {
      status: emitResult.success ? 'enviada' : 'rascunho',
      providerNFeId: emitResult.providerNFeId ?? null,
      accessKey: emitResult.accessKey ?? null,
      xmlUrl: emitResult.xmlUrl ?? null,
      pdfUrl: emitResult.pdfUrl ?? null,
      errorMessage: emitResult.errorMessage ?? null,
      issuedAt: emitResult.success ? new Date() : null,
    },
  });

  return { id: updated.id, status: updated.status, errorMessage: emitResult.errorMessage };
}

// ─────────────────────────────────────────────────────────────────────────────
// Gerar Boleto / PIX
// ─────────────────────────────────────────────────────────────────────────────
async function generateBoleto(
  receivable: any,
  companyId: string
): Promise<{ id: string; status: string; errorMessage?: string }> {
  // Idempotência: não gerar se já existe cobrança ativa
  const existing = await prisma.boletoCharge.findFirst({
    where: { receivableId: receivable.id, status: { notIn: ['cancelado'] } },
    select: { id: true, status: true },
  });
  if (existing) return { id: existing.id, status: existing.status };

  if (!receivable.customerDoc) {
    // Sem CPF/CNPJ cria apenas como rascunho local (sem enviar ao provider)
    const charge = await prisma.boletoCharge.create({
      data: {
        companyId,
        receivableId: receivable.id,
        type: 'boleto',
        status: 'pendente',
        customerName: receivable.customerName || 'Consumidor',
        amount: receivable.amount,
        dueDate: receivable.dueDate,
        description: receivable.description,
        createdBy: receivable.createdBy,
      },
    });
    return { id: charge.id, status: charge.status, errorMessage: 'CPF/CNPJ não informado — boleto não enviado ao provedor' };
  }

  const payload: ChargePayload = {
    type: 'boleto',
    customerName: receivable.customerName || 'Consumidor',
    customerDoc: receivable.customerDoc,
    customerEmail: receivable.customerEmail || undefined,
    amount: receivable.amount,
    dueDate: receivable.dueDate,
    description: receivable.description || undefined,
    externalId: receivable.id,
  };

  const chargeResult = await createCharge(companyId, payload);

  const charge = await prisma.boletoCharge.create({
    data: {
      companyId,
      receivableId: receivable.id,
      type: 'boleto',
      status: chargeResult.success ? 'pendente' : 'pendente',
      customerName: receivable.customerName || 'Consumidor',
      customerDoc: receivable.customerDoc,
      customerEmail: receivable.customerEmail,
      amount: receivable.amount,
      dueDate: receivable.dueDate,
      description: receivable.description,
      providerChargeId: chargeResult.providerChargeId ?? null,
      boletoBarCode: chargeResult.boletoBarCode ?? null,
      boletoUrl: chargeResult.boletoUrl ?? null,
      pixCopiaECola: chargeResult.pixCopiaECola ?? null,
      pixQrCodeUrl: chargeResult.pixQrCodeUrl ?? null,
      pixExpiresAt: chargeResult.pixExpiresAt ?? null,
      createdBy: receivable.createdBy,
    },
  });

  return {
    id: charge.id,
    status: charge.status,
    errorMessage: chargeResult.success ? undefined : chargeResult.errorMessage,
  };
}
