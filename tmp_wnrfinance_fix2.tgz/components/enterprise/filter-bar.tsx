'use client';

import { useState, ReactNode } from 'react';
import { Search, Filter, ChevronDown, ChevronUp, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface FilterBarProps {
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  searchPlaceholder?: string;
  children?: ReactNode;           // filter controls (selects, date pickers, etc.)
  actions?: ReactNode;            // action buttons on the right
  collapsible?: boolean;
  defaultExpanded?: boolean;
  activeFilterCount?: number;
  onClearFilters?: () => void;
}

export function FilterBar({
  searchValue,
  onSearchChange,
  searchPlaceholder = 'Buscar...',
  children,
  actions,
  collapsible = false,
  defaultExpanded = true,
  activeFilterCount = 0,
  onClearFilters,
}: FilterBarProps) {
  const [expanded, setExpanded] = useState(defaultExpanded);

  return (
    <div className="bg-card border border-border/60 rounded-xl mb-4 overflow-hidden">
      {/* Main bar */}
      <div className="flex items-center gap-3 px-4 py-3">
        {/* Search */}
        {onSearchChange && (
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={searchValue || ''}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={searchPlaceholder}
              className="pl-9 h-9 text-sm bg-background"
            />
          </div>
        )}

        {/* Collapsible toggle */}
        {collapsible && children && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => setExpanded(!expanded)}
            className="gap-1.5 text-xs h-9"
          >
            <Filter className="w-3.5 h-3.5" />
            Filtros
            {activeFilterCount > 0 && (
              <span className="bg-blue-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-bold">
                {activeFilterCount}
              </span>
            )}
            {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </Button>
        )}

        {/* Active filter clear */}
        {activeFilterCount > 0 && onClearFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearFilters}
            className="gap-1 text-xs h-9 text-muted-foreground hover:text-foreground"
          >
            <X className="w-3 h-3" />
            Limpar
          </Button>
        )}

        {/* Actions */}
        {actions && (
          <div className="ml-auto flex items-center gap-2">
            {actions}
          </div>
        )}
      </div>

      {/* Expanded filters */}
      {children && (!collapsible || expanded) && (
        <div className="px-4 pb-3 pt-0 flex flex-wrap gap-3 items-end border-t border-border/40 mt-0 pt-3">
          {children}
        </div>
      )}
    </div>
  );
}
