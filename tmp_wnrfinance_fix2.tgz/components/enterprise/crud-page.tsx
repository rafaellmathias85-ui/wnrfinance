'use client';

import { useState, useEffect, useCallback, ReactNode } from 'react';
import { PageHeader } from '@/components/enterprise';
import { apiFetch } from '@/lib/fetch';
import { Plus, Search, Pencil, Trash2, X, Loader2, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

export interface CrudColumn {
  key: string;
  label: string;
  render?: (value: any, row: any) => ReactNode;
  className?: string;
}

export interface CrudField {
  key: string;
  label: string;
  type?: 'text' | 'number' | 'select' | 'textarea' | 'date' | 'email';
  required?: boolean;
  options?: { value: string; label: string }[];
  placeholder?: string;
  defaultValue?: any;
}

interface CrudPageProps {
  title: string;
  subtitle: string;
  apiUrl: string;
  columns: CrudColumn[];
  fields: CrudField[];
  searchKey?: string;
  newLabel?: string;
  entityName?: string;
}

export function CrudPage({
  title, subtitle, apiUrl, columns, fields,
  searchKey = 'name', newLabel = 'Novo', entityName = 'registro',
}: CrudPageProps) {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState(false);
  const [page, setPage] = useState(0);
  const perPage = 15;

  const load = useCallback(async () => {
    try {
      const r = await apiFetch(apiUrl);
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Erro ao carregar');
      setItems(Array.isArray(d) ? d : d.items || []);
    } catch (err: any) { toast({ title: err.message || 'Erro ao carregar', variant: 'destructive' }); }
    setLoading(false);
  }, [apiUrl, toast]);

  useEffect(() => { load(); }, [load]);

  const openNew = () => {
    setEditing(null);
    const defaults: Record<string, any> = {};
    fields.forEach(f => { defaults[f.key] = f.defaultValue ?? ''; });
    setForm(defaults);
    setShowForm(true);
  };

  const openEdit = (item: any) => {
    setEditing(item);
    const vals: Record<string, any> = {};
    fields.forEach(f => {
      let v = item[f.key];
      if (f.type === 'date' && v) v = v.slice(0, 10);
      vals[f.key] = v ?? '';
    });
    setForm(vals);
    setShowForm(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload: any = { ...form };
      fields.forEach(f => {
        if (f.type === 'number' && payload[f.key] !== '' && payload[f.key] !== undefined) {
          payload[f.key] = Number(payload[f.key]);
        }
        if (f.type === 'date' && payload[f.key]) {
          payload[f.key] = new Date(payload[f.key]).toISOString();
        }
      });
      if (editing) payload.id = editing.id;

      const r = await apiFetch(apiUrl, {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!r.ok) { const e = await r.json(); throw new Error(e.error || 'Erro'); }
      toast({ title: editing ? `${entityName} atualizado!` : `${entityName} criado!` });
      setShowForm(false);
      load();
    } catch (err: any) {
      toast({ title: err.message || 'Erro ao salvar', variant: 'destructive' });
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm(`Excluir ${entityName}?`)) return;
    try {
      const r = await apiFetch(`${apiUrl}?id=${id}`, { method: 'DELETE' });
      if (!r.ok) {
        const e = await r.json().catch(() => ({}));
        throw new Error(e.error || 'Erro');
      }
      toast({ title: `${entityName} exclu\u00eddo!` });
      load();
    } catch { toast({ title: 'Erro ao excluir', variant: 'destructive' }); }
  };

  const filtered = items.filter(item => {
    if (!search) return true;
    const s = search.toLowerCase();
    return columns.some(c => {
      const v = item[c.key];
      return v && String(v).toLowerCase().includes(s);
    });
  });

  const totalPages = Math.ceil(filtered.length / perPage);
  const paged = filtered.slice(page * perPage, (page + 1) * perPage);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title={title} subtitle={subtitle} />

      {/* Toolbar */}
      <div className="bg-card border border-border/60 rounded-xl p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Buscar..." value={search} onChange={e => { setSearch(e.target.value); setPage(0); }} className="pl-10" />
          </div>
          <Button size="sm" onClick={openNew}>
            <Plus className="w-4 h-4 mr-1.5" /> {newLabel}
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border/50 bg-muted/30">
                {columns.map(c => (
                  <th key={c.key} className={`text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider ${c.className || ''}`}>
                    {c.label}
                  </th>
                ))}
                <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider w-24">A\u00e7\u00f5es</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/30">
              {paged.length === 0 ? (
                <tr><td colSpan={columns.length + 1} className="px-4 py-12 text-center text-muted-foreground text-sm">Nenhum {entityName} encontrado.</td></tr>
              ) : paged.map(item => (
                <tr key={item.id} className="hover:bg-muted/30 transition-colors">
                  {columns.map(c => (
                    <td key={c.key} className={`px-4 py-3 text-sm ${c.className || ''}`}>
                      {c.render ? c.render(item[c.key], item) : (item[c.key] ?? '\u2014')}
                    </td>
                  ))}
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => openEdit(item)} className="p-1.5 rounded-lg hover:bg-muted transition-colors" title="Editar">
                        <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                      </button>
                      <button onClick={() => handleDelete(item.id)} className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors" title="Excluir">
                        <Trash2 className="w-3.5 h-3.5 text-red-500" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border/50">
            <span className="text-xs text-muted-foreground">{filtered.length} {entityName}(s)</span>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" disabled={page === 0} onClick={() => setPage(p => p - 1)}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <span className="text-xs text-muted-foreground px-2">{page + 1} / {totalPages}</span>
              <Button variant="ghost" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setShowForm(false)} />
          <div className="relative bg-card border border-border rounded-2xl shadow-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto m-4">
            <div className="sticky top-0 bg-card border-b border-border/60 px-6 py-4 flex items-center justify-between rounded-t-2xl">
              <h3 className="text-lg font-semibold">{editing ? `Editar ${entityName}` : `Novo ${entityName}`}</h3>
              <button onClick={() => setShowForm(false)} className="p-1 rounded hover:bg-muted"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              {fields.map(f => (
                <div key={f.key}>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">{f.label}{f.required && <span className="text-red-500"> *</span>}</label>
                  {f.type === 'select' ? (
                    <select
                      value={form[f.key] || ''}
                      onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                      className="w-full h-10 rounded-lg border border-border bg-background px-3 text-sm"
                    >
                      <option value="">Selecionar...</option>
                      {f.options?.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </select>
                  ) : f.type === 'textarea' ? (
                    <textarea
                      value={form[f.key] || ''}
                      onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                      className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm min-h-[80px]"
                      placeholder={f.placeholder}
                    />
                  ) : (
                    <Input
                      type={f.type || 'text'}
                      value={form[f.key] || ''}
                      onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                      placeholder={f.placeholder}
                      step={f.type === 'number' ? 'any' : undefined}
                    />
                  )}
                </div>
              ))}
            </div>
            <div className="sticky bottom-0 bg-card border-t border-border/60 px-6 py-4 flex justify-end gap-3 rounded-b-2xl">
              <Button variant="outline" size="sm" onClick={() => setShowForm(false)}>Cancelar</Button>
              <Button size="sm" onClick={handleSave} disabled={saving}>
                {saving && <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />}
                {editing ? 'Salvar' : 'Criar'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
