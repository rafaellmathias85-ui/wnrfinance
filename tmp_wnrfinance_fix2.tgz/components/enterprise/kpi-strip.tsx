'use client';

import { ReactNode } from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export interface KpiItem {
  label: string;
  value: string | ReactNode;
  change?: number;           // percentage change (e.g. 5.2 or -3.1)
  changeLabel?: string;      // e.g. "vs m\u00eas anterior"
  icon?: ReactNode;
  color?: 'default' | 'success' | 'danger' | 'warning' | 'info';
}

interface KpiStripProps {
  items: KpiItem[];
  className?: string;
}

const colorMap = {
  default: 'bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400',
  success: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400',
  danger: 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400',
  warning: 'bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400',
  info: 'bg-sky-50 text-sky-700 dark:bg-sky-900/20 dark:text-sky-400',
};

export function KpiStrip({ items, className = '' }: KpiStripProps) {
  return (
    <div className={`grid gap-4 mb-6 ${items.length === 1 ? 'grid-cols-1' : items.length === 2 ? 'grid-cols-1 sm:grid-cols-2' : items.length === 3 ? 'grid-cols-1 sm:grid-cols-3' : 'grid-cols-2 lg:grid-cols-4'} ${className}`}>
      {items.map((item, i) => (
        <div key={i} className="kpi-card group">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">{item.label}</p>
              <p className="text-xl lg:text-2xl font-bold text-foreground tracking-tight truncate">{item.value}</p>
            </div>
            {item.icon && (
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${colorMap[item.color || 'default']}`}>
                {item.icon}
              </div>
            )}
          </div>
          {item.change !== undefined && (
            <div className="flex items-center gap-1.5 mt-2">
              {item.change > 0 ? (
                <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
              ) : item.change < 0 ? (
                <TrendingDown className="w-3.5 h-3.5 text-red-500" />
              ) : (
                <Minus className="w-3.5 h-3.5 text-muted-foreground" />
              )}
              <span className={`text-xs font-semibold ${
                item.change > 0 ? 'text-emerald-600' : item.change < 0 ? 'text-red-600' : 'text-muted-foreground'
              }`}>
                {item.change > 0 ? '+' : ''}{item.change.toFixed(1)}%
              </span>
              {item.changeLabel && (
                <span className="text-[11px] text-muted-foreground">{item.changeLabel}</span>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
